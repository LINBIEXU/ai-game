"use client";

import { useEffect, useMemo, useRef, useState } from "react";

import { buildWorkRecords, restoreStateFromSnapshot } from "@/lib/cloud-save/serializers";
import type { CloudSaveResponse, CloudSaveStatus, CloudSessionState, CloudWorkRecord } from "@/types/cloud-save";
import type { GameState } from "@/types/game";

interface UseCloudSyncOptions {
  sessionState: CloudSessionState;
  state: GameState;
  isHydrated: boolean;
  replaceState: (next: GameState) => void;
}

function buildRequestHeaders(accessToken: string) {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${accessToken}`
  };
}

export function useCloudSync({ sessionState, state, isHydrated, replaceState }: UseCloudSyncOptions) {
  const [status, setStatus] = useState<CloudSaveStatus>(sessionState.stage === "disabled" ? "disabled" : "authenticating");
  const [error, setError] = useState<string | null>(null);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const [recentWorks, setRecentWorks] = useState<CloudWorkRecord[]>([]);
  const [didRestoreHistory, setDidRestoreHistory] = useState(false);
  const [statusMessage, setStatusMessage] = useState("主舰记忆正在接入。");
  const hasRestoredRef = useRef(false);
  const lastSavedSnapshotRef = useRef("");
  const saveTimerRef = useRef<number | null>(null);

  const serializedState = useMemo(() => JSON.stringify(state), [state]);

  useEffect(() => {
    if (sessionState.stage === "disabled") {
      setStatus("disabled");
      setStatusMessage("当前仍在使用本地记忆舱。");
      return;
    }

    if (sessionState.stage === "connecting") {
      setStatus("authenticating");
      setStatusMessage("匿名航海编号正在生成。");
      return;
    }

    if (sessionState.stage === "error") {
      setStatus("error");
      setError(sessionState.error);
      setStatusMessage("同步链路短暂失焦，本地记录仍会继续保留。");
    }
  }, [sessionState.error, sessionState.stage]);

  useEffect(() => {
    if (!isHydrated || sessionState.stage !== "ready" || hasRestoredRef.current) {
      return;
    }

    let cancelled = false;

    async function restore() {
      setStatus("restoring");
      setError(null);
      setStatusMessage("主舰正在接续你上次离开的航线。");

      try {
        const response = await fetch(
          `/api/cloud-save?authUid=${encodeURIComponent(sessionState.session!.authUid)}&loginType=${encodeURIComponent(
            sessionState.session!.loginType
          )}`,
          {
            method: "GET",
            cache: "no-store",
            headers: buildRequestHeaders(sessionState.session!.accessToken)
          }
        );
        const data = (await response.json().catch(() => null)) as CloudSaveResponse | null;

        if (!response.ok || !data?.ok || !data.snapshot) {
          throw new Error(data?.error ?? "云端存档暂时没有回应。");
        }

        const restored = restoreStateFromSnapshot(data.snapshot);

        if (cancelled) {
          return;
        }

        if (restored) {
          replaceState(restored.state);
          lastSavedSnapshotRef.current = JSON.stringify(restored.state);
          setLastSavedAt(restored.restoredAt);
          setRecentWorks([...data.snapshot.works].sort((left, right) => right.updatedAt - left.updatedAt).slice(0, 6));
          setDidRestoreHistory(true);
          setStatusMessage("已接续上次探索，主舰档案恢复完成。");
        } else {
          lastSavedSnapshotRef.current = serializedState;
          setRecentWorks([]);
          setDidRestoreHistory(false);
          setStatusMessage("已建立新的匿名航线档案。");
        }

        hasRestoredRef.current = true;
        setStatus("saved");
      } catch (restoreError) {
        if (cancelled) {
          return;
        }

        hasRestoredRef.current = true;
        lastSavedSnapshotRef.current = serializedState;
        setStatus("error");
        setError(restoreError instanceof Error ? restoreError.message : "云端存档恢复失败。");
        setStatusMessage("同步链路异常，主舰将先沿用本地记忆。");
      }
    }

    void restore();

    return () => {
      cancelled = true;
    };
  }, [isHydrated, replaceState, serializedState, sessionState]);

  useEffect(() => {
    if (!isHydrated || sessionState.stage !== "ready" || !hasRestoredRef.current) {
      return;
    }

    if (serializedState === lastSavedSnapshotRef.current) {
      return;
    }

    if (saveTimerRef.current) {
      window.clearTimeout(saveTimerRef.current);
    }

    saveTimerRef.current = window.setTimeout(() => {
      void (async () => {
        try {
          setStatus("saving");
          setError(null);
          setStatusMessage(
            state.currentScene === "crew-bay" || state.currentScene === "crew-chat" || state.currentScene === "crew-result"
              ? "船员记录正在写入主舰名册。"
              : state.signalMission.faultRun.status === "running"
                ? "故障回溯检查点正在同步。"
                : state.signalMission.planet.status === "restored"
                  ? "航行记忆与星图档案正在同步。"
                  : "主舰档案正在更新。"
          );

          const response = await fetch("/api/cloud-save", {
            method: "POST",
            headers: buildRequestHeaders(sessionState.session!.accessToken),
            body: JSON.stringify({
              authUid: sessionState.session!.authUid,
              loginType: sessionState.session!.loginType,
              state
            })
          });
          const data = (await response.json().catch(() => null)) as CloudSaveResponse | null;

          if (!response.ok || !data?.ok || !data.saveMeta) {
            throw new Error(data?.error ?? "云端存档写入失败。");
          }

          lastSavedSnapshotRef.current = serializedState;
          setLastSavedAt(data.saveMeta.updatedAt);
          setRecentWorks(
            buildWorkRecords(
              state,
              sessionState.session!.authUid,
              {
                repairedSignal: state.signalMission.repairedSignal,
                chapterTwoOutcome: state.chapterTwo.outcome
              }
            )
              .sort((left, right) => right.updatedAt - left.updatedAt)
              .slice(0, 6)
          );
          setStatus("saved");
          setStatusMessage(
            state.currentScene === "crew-bay" || state.currentScene === "crew-chat" || state.currentScene === "crew-result"
              ? "船员记录已写入主舰名册。"
              : state.signalMission.faultRun.status === "running"
                ? "故障回溯检查点已写入。"
                : state.signalMission.planet.status === "restored"
                  ? "航行记忆已同步到主舰档案。"
                  : "主舰档案已更新。"
          );
        } catch (saveError) {
          setStatus("error");
          setError(saveError instanceof Error ? saveError.message : "云端存档写入失败。");
          setStatusMessage("同步异常，本地记忆仍在继续保存。");
        }
      })();
    }, 1200);

    return () => {
      if (saveTimerRef.current) {
        window.clearTimeout(saveTimerRef.current);
      }
    };
  }, [isHydrated, serializedState, sessionState, state]);

  return {
    status,
    error,
    lastSavedAt,
    recentWorks,
    didRestoreHistory,
    statusMessage,
    hasCloudIdentity: sessionState.stage === "ready" && Boolean(sessionState.session?.authUid),
    authUid: sessionState.session?.authUid ?? null
  };
}
