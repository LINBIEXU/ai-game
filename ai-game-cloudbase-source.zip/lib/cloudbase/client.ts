"use client";

import cloudbase from "@cloudbase/js-sdk";

import { getCloudBaseClientConfig } from "@/lib/cloudbase/config";

let appInstance: ReturnType<typeof cloudbase.init> | null = null;

export function getCloudBaseApp() {
  const config = getCloudBaseClientConfig();

  if (!config.enabled || !config.envId) {
    return null;
  }

  if (!appInstance) {
    appInstance = cloudbase.init({
      env: config.envId
    });
    appInstance.auth({
      persistence: "local"
    });
  }

  return appInstance;
}
