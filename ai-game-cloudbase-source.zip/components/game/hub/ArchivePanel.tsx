"use client";

import type { CloudSaveStatus, CloudWorkRecord } from "@/types/cloud-save";
import type { CrewMember, GameState } from "@/types/game";

interface ArchivePanelProps {
  authUid: string | null;
  loginType: string | null;
  saveStatus: CloudSaveStatus;
  statusMessage: string;
  lastSavedAt: number | null;
  didRestoreHistory: boolean;
  crewRoster: CrewMember[];
  recentWorks: CloudWorkRecord[];
  state: GameState;
}

function sceneLabel(scene: GameState["currentScene"]) {
  return (
    {
      awakening: "主舱苏醒",
      hub: "主舰主舱",
      archive: "主舰档案舱",
      "hub-briefing": "同步简报",
      recruit: "船员招募台",
      "crew-result": "船员生成结果",
      "crew-bay": "船员舱",
      "crew-chat": "船员对话",
      logbook: "航海日志舱",
      "task-board": "任务台",
      "task-result": "任务结果",
      "signal-mission": "信息库第一关",
      "signal-review": "信息库修复界面",
      "signal-aftermath": "信息库修复后",
      "chapter-complete": "第一章总结",
      "chapter-two-portal": "第二章入口",
      "chapter-two-mission": "第二章推进中",
      "chapter-two-result": "第二章结果"
    } as Record<GameState["currentScene"], string>
  )[scene];
}

function formatTime(timestamp: number | null) {
  if (!timestamp) {
    return "尚未写入";
  }

  return new Intl.DateTimeFormat("zh-CN", {
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }).format(timestamp);
}

function resolveProgressAnchor(state: GameState) {
  if (!state.crewOnboard) return "船员招募台";
  if (state.signalMission.faultRun.status === "running") return "故障回溯演算";
  if (state.signalMission.planet.status === "restored" && !state.signalMission.repairedSignal) return "信息库第二关入口";
  if (state.signalMission.planet.status === "analyzed") return "第一关星球建模确认";
  if (state.signalMission.planet.status === "input" && state.firstStarLit) return "信息库第一关";
  if (state.chapterTwo.currentStep !== "response" || state.chapterTwo.echo) return "第二章协作解析";
  return sceneLabel(state.currentScene === "archive" || state.currentScene === "logbook" ? "hub" : state.currentScene);
}

export function ArchivePanel({
  authUid,
  loginType,
  saveStatus,
  statusMessage,
  lastSavedAt,
  didRestoreHistory,
  crewRoster,
  recentWorks,
  state
}: ArchivePanelProps) {
  const latestLogs = state.shipLogs.slice(0, 3);
  const currentFaultNode = state.signalMission.faultRun.nodes[state.signalMission.faultRun.currentNodeIndex] ?? null;
  const progressNotes = [
    `当前停留：${resolveProgressAnchor(state)}`,
    state.signalMission.planet.confirmedModel ? `已建模星球：${state.signalMission.planet.confirmedModel.name}` : "第一颗星球仍待写回星图",
    state.signalMission.faultRun.status === "running"
      ? `故障回溯进行到：${currentFaultNode?.stage ?? "回溯链中段"}`
      : state.signalMission.repairedSignal
        ? "故障案例库已恢复"
        : "故障回溯尚未完成"
  ];

  return (
    <section className="scene-reveal space-y-5">
      <div className="fleet-broadcast panel-surface rounded-full px-4 py-2">
        <div className="fleet-broadcast-track">
          {[
            didRestoreHistory ? "已接续上次探索" : "新的匿名航线已建立",
            statusMessage,
            `最近保存 ${formatTime(lastSavedAt)}`,
            `船员名册 ${crewRoster.length}`,
            didRestoreHistory ? "主舰记得你来过这里" : "本次探索会从这里开始",
            didRestoreHistory ? "已接续上次探索" : "新的匿名航线已建立",
            statusMessage
          ].map((item, index) => (
            <span key={`${item}-${index}`} className="fleet-broadcast-item">
              {item}
            </span>
          ))}
        </div>
      </div>

      <div className="panel-surface rounded-[32px] p-6 md:p-8">
        <div className="soft-label text-[11px] text-white/42">主舰存档页</div>
        <h2 className="mt-3 text-3xl font-semibold text-white">这艘船已经开始记住你。</h2>

        <div className="mt-6 grid gap-4 lg:grid-cols-[0.92fr_1.08fr]">
          <div className="space-y-4">
            <div className="rounded-[24px] border border-cyan-200/14 bg-cyan-200/[0.06] p-5">
              <div className="text-sm font-semibold text-white">当前身份</div>
              <div className="mt-3 text-sm leading-6 text-white/64">
                {loginType ? `身份类型：${loginType === "ANONYMOUS" ? "匿名探索者" : loginType}` : "身份仍在接入中"}
              </div>
              <div className="mt-2 text-sm leading-6 text-white/64">{authUid ? `匿名编号：${authUid}` : "尚未拿到匿名编号"}</div>
              <div className="mt-4 inline-flex rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-white/68">
                {saveStatus === "saving" ? "主舰正在同步" : saveStatus === "error" ? "同步异常，已保留本地记忆" : statusMessage}
              </div>
            </div>

            <div className="rounded-[24px] border border-white/8 bg-white/[0.03] p-5">
              <div className="text-sm font-semibold text-white">当前主线停留</div>
              <div className="mt-3 space-y-2 text-sm leading-6 text-white/62">
                {progressNotes.map((item) => (
                  <div key={item}>{item}</div>
                ))}
              </div>
              <div className="mt-4 text-xs text-white/45">
                最近一次保存：{formatTime(lastSavedAt)} · {didRestoreHistory ? "本次进入已恢复历史进度" : "本次是新的探索起点"}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded-[24px] border border-white/8 bg-white/[0.03] p-5">
              <div className="flex items-center justify-between gap-3">
                <div className="text-sm font-semibold text-white">当前拥有的船员</div>
                <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[10px] tracking-[0.18em] text-white/46">
                  {crewRoster.length} 位在线
                </span>
              </div>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {crewRoster.length === 0 && (
                  <div className="rounded-[18px] border border-dashed border-white/14 bg-white/[0.02] p-4 text-sm leading-6 text-white/56">
                    主舰还在等第一位伙伴登船。
                  </div>
                )}
                {crewRoster.map((crew) => (
                  <div key={crew.id} className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <div className="text-sm font-semibold text-white">{crew.name}</div>
                    <div className="mt-1 text-xs text-cyan-100/72">{crew.title}</div>
                    <div className="mt-2 text-xs leading-6 text-white/56">{crew.bondStatus}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-[24px] border border-white/8 bg-white/[0.03] p-5">
              <div className="text-sm font-semibold text-white">最近作品</div>
              <div className="mt-4 space-y-3">
                {recentWorks.length === 0 && (
                  <div className="rounded-[18px] border border-dashed border-white/14 bg-white/[0.02] p-4 text-sm leading-6 text-white/56">
                    还没有可归档的作品。完成星球建模、信息库修复或第二章结果后，这里会开始留下作品。
                  </div>
                )}
                {recentWorks.map((work) => (
                  <article key={work._id} className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="text-sm font-semibold text-white">{work.title}</div>
                      <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[10px] tracking-[0.14em] text-white/46">
                        {work.type}
                      </span>
                    </div>
                    <div className="mt-2 text-sm leading-6 text-white/62">{work.content}</div>
                  </article>
                ))}
              </div>
            </div>

            <div className="rounded-[24px] border border-white/8 bg-white/[0.03] p-5">
              <div className="text-sm font-semibold text-white">最近主舰日志</div>
              <div className="mt-4 space-y-3">
                {latestLogs.length === 0 && (
                  <div className="rounded-[18px] border border-dashed border-white/14 bg-white/[0.02] p-4 text-sm leading-6 text-white/56">
                    日志舱还没写入新的航海记录。
                  </div>
                )}
                {latestLogs.map((entry) => (
                  <div key={entry.id} className="rounded-[18px] border border-white/8 bg-slate-950/35 p-4">
                    <div className="text-sm font-semibold text-white">{entry.title}</div>
                    <div className="mt-2 text-sm leading-6 text-white/60">{entry.body}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
