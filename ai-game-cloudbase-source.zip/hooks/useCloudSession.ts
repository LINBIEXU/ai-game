"use client";

import { useEffect, useState } from "react";

import { getCloudBaseApp } from "@/lib/cloudbase/client";
import type { CloudSessionState } from "@/types/cloud-save";

const disabledState: CloudSessionState = {
  stage: "disabled",
  session: null,
  error: null
};

export function useCloudSession() {
  const [state, setState] = useState<CloudSessionState>({
    stage: "connecting",
    session: null,
    error: null
  });

  useEffect(() => {
    let cancelled = false;
    const app = getCloudBaseApp();

    if (!app) {
      setState(disabledState);
      return;
    }

    const auth = app.auth({
      persistence: "local"
    });

    async function bootstrap() {
      try {
        let loginState = await auth.getLoginState();

        if (!loginState?.user?.uid) {
          await auth.signInAnonymously();
          loginState = await auth.getLoginState();
        }

        const user = loginState?.user ?? (await auth.getCurrentUser());
        const token = await auth.getAccessToken();

        if (!user?.uid || !token?.accessToken) {
          throw new Error("匿名身份未能建立。");
        }

        if (cancelled) {
          return;
        }

        setState({
          stage: "ready",
          session: {
            authUid: user.uid,
            loginType: user.loginType ?? "ANONYMOUS",
            accessToken: token.accessToken
          },
          error: null
        });
      } catch (error) {
        if (cancelled) {
          return;
        }

        setState({
          stage: "error",
          session: null,
          error: error instanceof Error ? error.message : "匿名登录失败。"
        });
      }
    }

    void bootstrap();

    return () => {
      cancelled = true;
    };
  }, []);

  return state;
}
