import { createInitialGameState } from "@/lib/game-constants";
import type {
  CloudCrewRecord,
  CloudProgressRecord,
  CloudSnapshot,
  CloudWorkRecord,
  RestoreEnvelope,
  WorkBuildContext
} from "@/types/cloud-save";
import type { CrewMember, GameState, PlanetModel } from "@/types/game";

function uniqueCrewPool(state: GameState) {
  const pool = new Map<string, CrewMember>();

  if (state.generatedCrew) {
    pool.set(state.generatedCrew.id, state.generatedCrew);
  }

  state.crewRoster.forEach((crew) => {
    pool.set(crew.id, crew);
  });

  return Array.from(pool.values());
}

function createdAtFromCrew(crew: CrewMember) {
  return (
    crew.portraitAsset?.updatedAt ??
    crew.portraitEchoes[crew.portraitEchoes.length - 1]?.updatedAt ??
    Date.now()
  );
}

export function buildCrewRecords(state: GameState, userId: string, existing = new Map<string, CloudCrewRecord>()): CloudCrewRecord[] {
  const now = Date.now();
  const onboardIds = new Set(state.crewRoster.map((crew) => crew.id));

  return uniqueCrewPool(state).map((crew) => {
    const current = existing.get(`${userId}:${crew.id}`);

    return {
      _id: `${userId}:${crew.id}`,
      userId,
      name: crew.name,
      profile: crew,
      echoes: crew.portraitEchoes,
      bond: {
        trustLevel: crew.trustLevel,
        trustLabel: crew.trustLabel,
        bondStatus: crew.bondStatus
      },
      metadata: {
        isOnboard: onboardIds.has(crew.id),
        isGenerated: state.generatedCrew?.id === crew.id,
        isActive: state.activeCrewId === crew.id
      },
      createdAt: current?.createdAt ?? createdAtFromCrew(crew),
      updatedAt: now
    };
  });
}

function planetWorkContent(planet: PlanetModel) {
  return `${planet.summary} 资源分布为 水源 ${planet.resourceProfile.water} / 矿物 ${planet.resourceProfile.mineral} / 能源 ${planet.resourceProfile.energy} / 生态 ${planet.resourceProfile.ecology} / 遗迹数据 ${planet.resourceProfile.relicData}。`;
}

export function buildWorkRecords(
  state: GameState,
  userId: string,
  context: WorkBuildContext,
  existing = new Map<string, CloudWorkRecord>()
): CloudWorkRecord[] {
  const now = Date.now();
  const works: CloudWorkRecord[] = state.planetCatalog.map((planet) => {
    const id = `${userId}:planet-model:${planet.id}`;
    const current = existing.get(id);

    return {
      _id: id,
      userId,
      type: "planet-model",
      title: planet.name,
      content: planetWorkContent(planet),
      metadata: {
        coordinateLabel: planet.coordinateLabel,
        mood: planet.mood,
        dangerLabel: planet.dangerLabel,
        tags: planet.tags,
        resourceProfile: planet.resourceProfile,
        production: planet.production,
        explorationHooks: planet.explorationHooks
      },
      createdAt: current?.createdAt ?? now,
      updatedAt: now
    };
  });

  if (context.repairedSignal) {
    const id = `${userId}:memory-vault-report:${context.repairedSignal.coordinateLabel}`;
    const current = existing.get(id);
    works.push({
      _id: id,
      userId,
      type: "memory-vault-report",
      title: context.repairedSignal.title,
      content: context.repairedSignal.summary,
      metadata: {
        coordinateLabel: context.repairedSignal.coordinateLabel,
        repairSummary: context.repairedSignal.repairSummary,
        restoredFeatures: context.repairedSignal.restoredFeatures,
        nextLead: context.repairedSignal.nextLead
      },
      createdAt: current?.createdAt ?? now,
      updatedAt: now
    });
  }

  if (context.chapterTwoOutcome) {
    const id = `${userId}:chapter-two-outcome:${context.chapterTwoOutcome.scannedZone}`;
    const current = existing.get(id);
    works.push({
      _id: id,
      userId,
      type: "chapter-two-outcome",
      title: context.chapterTwoOutcome.title,
      content: context.chapterTwoOutcome.summary,
      metadata: {
        worldChange: context.chapterTwoOutcome.worldChange,
        scannedZone: context.chapterTwoOutcome.scannedZone,
        chapterThreeHook: context.chapterTwoOutcome.chapterThreeHook
      },
      createdAt: current?.createdAt ?? now,
      updatedAt: now
    });
  }

  return works;
}

export function buildProgressRecord(state: GameState, userId: string, existing?: CloudProgressRecord | null): CloudProgressRecord {
  return {
    _id: `${userId}:main`,
    userId,
    chapter: {
      currentScene: state.currentScene,
      chapterComplete: state.chapterComplete,
      chapterTwoUnlocked: state.chapterTwoUnlocked,
      chapterTwoComplete: state.chapterTwoComplete
    },
    memoryVault: state.signalMission,
    planetUnlocked: state.signalMission.planet.status === "restored" || state.planetCatalog.length > 0,
    faultRunState: state.signalMission.faultRun,
    progression: {
      activeCrewId: state.activeCrewId,
      crewVariant: state.crewVariant,
      crewOnboard: state.crewOnboard,
      systemsRestored: state.systemsRestored,
      hubSignalSeen: state.hubSignalSeen,
      firstStarLit: state.firstStarLit,
      chapterTwoRouteLocked: state.chapterTwoRouteLocked,
      chapterThreeHintUnlocked: state.chapterThreeHintUnlocked,
      scannedRegionLabel: state.scannedRegionLabel,
      newRegionAlert: state.newRegionAlert
    },
    generatedCrewId: state.generatedCrew?.id ?? null,
    planetCatalog: state.planetCatalog,
    faultCaseRecords: state.faultCaseRecords,
    taskDesk: state.taskDesk,
    chapterTwoState: state.chapterTwo,
    shipLogs: state.shipLogs,
    shipStatusNote: state.shipStatusNote,
    updatedAt: Date.now()
  };
}

export function restoreStateFromSnapshot(snapshot: CloudSnapshot): RestoreEnvelope | null {
  if (!snapshot.progress) {
    return null;
  }

  const base = createInitialGameState();
  const crewDocs = [...snapshot.crews].sort((left, right) => right.updatedAt - left.updatedAt);
  const crewMap = new Map(crewDocs.map((item) => [item.profile.id, item.profile]));
  const roster = crewDocs.filter((item) => item.metadata.isOnboard).map((item) => item.profile);
  const generatedCrew =
    (snapshot.progress.generatedCrewId ? crewMap.get(snapshot.progress.generatedCrewId) : null) ??
    crewDocs.find((item) => item.metadata.isGenerated)?.profile ??
    null;

  return {
    restoredAt: snapshot.progress.updatedAt,
    works: snapshot.works,
    state: {
      ...base,
      currentScene: snapshot.progress.chapter.currentScene,
      crewVariant: snapshot.progress.progression.crewVariant,
      generatedCrew,
      crewRoster: roster,
      activeCrewId: snapshot.progress.progression.activeCrewId,
      crewOnboard: snapshot.progress.progression.crewOnboard,
      systemsRestored: snapshot.progress.progression.systemsRestored,
      hubSignalSeen: snapshot.progress.progression.hubSignalSeen,
      firstStarLit: snapshot.progress.progression.firstStarLit,
      chapterComplete: snapshot.progress.chapter.chapterComplete,
      chapterTwoUnlocked: snapshot.progress.chapter.chapterTwoUnlocked,
      chapterTwoRouteLocked: snapshot.progress.progression.chapterTwoRouteLocked,
      chapterTwoComplete: snapshot.progress.chapter.chapterTwoComplete,
      chapterThreeHintUnlocked: snapshot.progress.progression.chapterThreeHintUnlocked,
      scannedRegionLabel: snapshot.progress.progression.scannedRegionLabel,
      newRegionAlert: snapshot.progress.progression.newRegionAlert,
      planetCatalog: snapshot.progress.planetCatalog,
      faultCaseRecords: snapshot.progress.faultCaseRecords,
      signalMission: snapshot.progress.memoryVault,
      taskDesk: snapshot.progress.taskDesk,
      chapterTwo: snapshot.progress.chapterTwoState,
      shipLogs: snapshot.progress.shipLogs,
      shipStatusNote: snapshot.progress.shipStatusNote
    }
  };
}
