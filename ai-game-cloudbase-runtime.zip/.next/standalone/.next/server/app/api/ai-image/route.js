"use strict";(()=>{var e={};e.id=248,e.ids=[248],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},35680:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>_,patchFetch:()=>I,requestAsyncStorage:()=>A,routeModule:()=>w,serverHooks:()=>k,staticGenerationAsyncStorage:()=>v});var i={};r.r(i),r.d(i,{POST:()=>x,dynamic:()=>h,maxDuration:()=>b,runtime:()=>y});var a=r(49303),o=r(88716),s=r(60670),l=r(87070);function n(e,t=0){if(null==e||0===e.trim().length)return t;let r=Number(e);return Number.isFinite(r)&&r>0?r:t}function c(){let e="real"===(process.env.AI_PROVIDER_MODE??"real")?"real":"mock",t=function(e,t="mock"){return"dashscope"===e?"dashscope":"real"===t?"dashscope":"mock"}(process.env.AI_IMAGE_PROVIDER??"dashscope",e);return{mode:e,providerId:t,allowMockFallback:function(e,t=!0){return null==e?t:"false"!==e}(process.env.AI_ALLOW_MOCK_FALLBACK,!0),polling:{maxAttempts:n(process.env.DASHSCOPE_IMAGE_POLL_MAX_ATTEMPTS,48),initialDelayMs:n(process.env.DASHSCOPE_IMAGE_POLL_INITIAL_DELAY_MS,2500),intervalMs:n(process.env.DASHSCOPE_IMAGE_POLL_INTERVAL_MS,3e3)},dashscope:{apiKey:process.env.DASHSCOPE_API_KEY??null,generationUrl:process.env.DASHSCOPE_IMAGE_GENERATION_URL??"https://dashscope.aliyuncs.com/api/v1/services/aigc/image-generation/generation",model:process.env.DASHSCOPE_IMAGE_MODEL??"wan2.7-image"}}}var p=r(59774);let u={mode:"mock",providerId:"mock",prompts:{worldRules:p.K.worldRules,generateCrewImage:p.K.generateCrewImage},generateCrewImage(e){var t;let r=p.K.generateCrewImage(e),i=e.variant??1;return{asset:{imageUrl:(t=function(e){var t,r;let{crew:i}=e,[a,o]="mechanical"===(t=i.formType)?["#99f6e4","#0f172a"]:"biological"===t?["#86efac","#052e16"]:"energy"===t?["#c4b5fd","#172554"]:["#fcd34d","#4c0519"],s=i.signalKeywords.slice(0,3).join(" \xb7 ")||i.abilityTag,l=`${i.name} / ${i.abilityTag}`,n=(r=i.visualSubject).includes("猫")?`
      <ellipse cx="384" cy="585" rx="120" ry="152" fill="rgba(255,255,255,0.16)" />
      <circle cx="384" cy="310" r="102" fill="rgba(255,255,255,0.2)" />
      <polygon points="320,238 352,168 382,246" fill="rgba(255,255,255,0.18)" />
      <polygon points="448,238 416,168 386,246" fill="rgba(255,255,255,0.18)" />
      <path d="M470 585c78 16 92 108 38 150" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="26" stroke-linecap="round"/>
      <circle cx="352" cy="298" r="9" fill="rgba(255,255,255,0.82)" />
      <circle cx="416" cy="298" r="9" fill="rgba(255,255,255,0.82)" />
      <path d="M366 338h36" stroke="rgba(255,255,255,0.65)" stroke-width="8" stroke-linecap="round" />
    `:r.includes("犬")||r.includes("狐")?`
      <ellipse cx="384" cy="588" rx="126" ry="150" fill="rgba(255,255,255,0.15)" />
      <circle cx="384" cy="308" r="98" fill="rgba(255,255,255,0.2)" />
      <polygon points="330,236 354,172 384,246" fill="rgba(255,255,255,0.18)" />
      <polygon points="438,236 414,172 384,246" fill="rgba(255,255,255,0.18)" />
      <path d="M360 332c20 18 48 18 68 0" stroke="rgba(255,255,255,0.52)" stroke-width="8" stroke-linecap="round" />
      <circle cx="352" cy="294" r="9" fill="rgba(255,255,255,0.82)" />
      <circle cx="416" cy="294" r="9" fill="rgba(255,255,255,0.82)" />
    `:r.includes("鸟")?`
      <ellipse cx="384" cy="575" rx="118" ry="160" fill="rgba(255,255,255,0.14)" />
      <circle cx="384" cy="296" r="88" fill="rgba(255,255,255,0.2)" />
      <path d="M250 432c78 36 118 44 134 62" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="28" stroke-linecap="round" />
      <path d="M518 432c-78 36 -118 44 -134 62" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="28" stroke-linecap="round" />
      <path d="M384 316l24 18-24 14-24-14z" fill="rgba(255,255,255,0.56)" />
      <circle cx="362" cy="282" r="8" fill="rgba(255,255,255,0.82)" />
      <circle cx="406" cy="282" r="8" fill="rgba(255,255,255,0.82)" />
    `:r.includes("能量")?`
      <circle cx="384" cy="328" r="112" fill="rgba(255,255,255,0.26)" />
      <ellipse cx="384" cy="570" rx="122" ry="168" fill="rgba(255,255,255,0.12)" />
      <ellipse cx="384" cy="520" rx="180" ry="82" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="16" />
      <ellipse cx="384" cy="632" rx="148" ry="60" fill="none" stroke="rgba(255,255,255,0.16)" stroke-width="12" />
    `:r.includes("机械")?`
      <rect x="286" y="420" width="196" height="266" rx="72" fill="rgba(255,255,255,0.14)" />
      <rect x="306" y="210" width="156" height="166" rx="54" fill="rgba(255,255,255,0.2)" />
      <circle cx="352" cy="280" r="10" fill="rgba(255,255,255,0.82)" />
      <circle cx="416" cy="280" r="10" fill="rgba(255,255,255,0.82)" />
      <rect x="332" y="324" width="104" height="12" rx="6" fill="rgba(255,255,255,0.55)" />
      <path d="M274 516h-44M494 516h44" stroke="rgba(255,255,255,0.24)" stroke-width="22" stroke-linecap="round" />
    `:`
    <ellipse cx="384" cy="582" rx="122" ry="154" fill="rgba(255,255,255,0.14)" />
    <circle cx="384" cy="296" r="96" fill="rgba(255,255,255,0.2)" />
    <circle cx="352" cy="280" r="10" fill="rgba(255,255,255,0.82)" />
    <circle cx="416" cy="280" r="10" fill="rgba(255,255,255,0.82)" />
    <rect x="332" y="322" width="104" height="12" rx="6" fill="rgba(255,255,255,0.55)" />
  `;return`
  <svg xmlns="http://www.w3.org/2000/svg" width="768" height="960" viewBox="0 0 768 960">
    <defs>
      <linearGradient id="bg" x1="0" x2="1" y1="0" y2="1">
        <stop offset="0%" stop-color="${a}" stop-opacity="0.92"/>
        <stop offset="100%" stop-color="${o}" stop-opacity="1"/>
      </linearGradient>
      <radialGradient id="glow" cx="50%" cy="34%" r="46%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.52"/>
        <stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="768" height="960" fill="#020617"/>
    <rect x="32" y="32" width="704" height="896" rx="44" fill="url(#bg)" opacity="0.2" stroke="rgba(255,255,255,0.12)"/>
    <circle cx="384" cy="280" r="210" fill="url(#glow)" />
    ${n}
    <text x="64" y="812" fill="rgba(255,255,255,0.96)" font-family="Arial, sans-serif" font-size="42" font-weight="700">${l}</text>
    <text x="64" y="862" fill="rgba(255,255,255,0.72)" font-family="Arial, sans-serif" font-size="24">${i.title}</text>
    <text x="64" y="904" fill="rgba(255,255,255,0.56)" font-family="Arial, sans-serif" font-size="22">${i.visualSubject} \xb7 ${s}</text>
  </svg>
  `}(e),`data:image/svg+xml;charset=UTF-8,${encodeURIComponent(t)}`),prompt:r.user,negativePrompt:r.negative,providerId:"mock",styleLabel:i<=1?"主宇宙回响":`平行回响 ${i}`,echoNote:function(e,t){let r=[`${e} 的基础轮廓与主舰第一次完成同步。`,`${e} 保持稳定，只是外层服装与光谱温度来自另一条分支。`,`${e} 的身份没有改变，这一版更像从侧向宇宙投来的影像。`];return r[Math.max(0,t-1)%r.length]}(e.crew.visualSubject,i),updatedAt:Date.now(),revision:i}}}};function g(e){return e.replace(/血腥|血液|伤口|尸体|恐怖|惊悚|黑暗化|阴暗化|成人化|性感化/g,"").replace(/严格避免：/g,"风格限制：").replace(/\s{2,}/g," ").trim()}function f(e){return/inappropriate content|不适宜|敏感|违规|ip infringement|侵权|知识产权|版权/i.test(e)}async function d(e){for(let t=0;t<e.maxAttempts;t+=1){await function(e){return new Promise(t=>setTimeout(t,e))}(0===t?e.initialDelayMs:e.intervalMs);let r=await fetch(`https://dashscope.aliyuncs.com/api/v1/tasks/${e.taskId}`,{method:"GET",headers:{Authorization:`Bearer ${e.apiKey}`},cache:"no-store"}),i=await r.json().catch(()=>null);if(!r.ok)throw Error(i&&"object"==typeof i&&"message"in i&&"string"==typeof i.message?i.message:`阿里百炼图像任务查询返回 ${r.status}`);let a=i&&"object"==typeof i&&"output"in i&&i.output&&"object"==typeof i.output&&"task_status"in i.output?String(i.output.task_status):"";if("SUCCEEDED"===a)return i;if("FAILED"===a||"CANCELED"===a||"UNKNOWN"===a)throw Error(i&&"object"==typeof i&&"output"in i&&i.output&&"object"==typeof i.output&&"message"in i.output?String(i.output.message):"船员形象任务未能完成。")}throw Error("船员形象生成等待时间过长，主舰已暂时切回本地外形回路。")}let m={mode:"real",providerId:"dashscope",prompts:{worldRules:p.K.worldRules,generateCrewImage:p.K.generateCrewImage},async generateCrewImage(e){let t;let r=c(),i=p.K.generateCrewImage(e),a=e.variant??1,o=g(`${i.user}

最终硬约束：整张图片里不能出现任何文字、字母、数字、标牌、铭牌、徽章字样、Logo、水印或可读符号。只要有任何可读字符都算失败。`),s=g(i.negative??""),l=await fetch(r.dashscope.generationUrl,{method:"POST",headers:{Authorization:`Bearer ${r.dashscope.apiKey}`,"Content-Type":"application/json","X-DashScope-Async":"enable"},body:JSON.stringify({model:r.dashscope.model,input:{messages:[{role:"user",content:[{text:s?`${o}

风格限制：${s}`:o}]}]},parameters:{size:"2K",n:1,watermark:!1,thinking_mode:!0}}),cache:"no-store"}),n=await l.json().catch(()=>null);if(!l.ok){let t=n&&"object"==typeof n&&"message"in n&&"string"==typeof n.message?n.message:`阿里百炼图像接口返回 ${l.status}`;if(f(t))return u.generateCrewImage(e);throw Error(t)}let m=function(e){if(!e||"object"!=typeof e||!("output"in e)||!e.output||"object"!=typeof e.output)return null;let t=e.output;return"string"==typeof t.task_id&&t.task_id.trim()?t.task_id.trim():null}(n);try{t=m?await d({taskId:m,apiKey:r.dashscope.apiKey,maxAttempts:r.polling.maxAttempts,initialDelayMs:r.polling.initialDelayMs,intervalMs:r.polling.intervalMs}):n}catch(t){if(t instanceof Error&&f(t.message))return u.generateCrewImage(e);throw t}let y=function(e){if(!e||"object"!=typeof e)return null;let t="output"in e&&e.output&&"object"==typeof e.output?e.output:null;for(let e of t&&Array.isArray(t.results)?t.results:t&&Array.isArray(t.result)?t.result:[])if(e&&"object"==typeof e&&"string"==typeof e.url&&e.url.trim())return e.url.trim();if(t&&"string"==typeof t.image_url&&t.image_url.trim())return t.image_url.trim();for(let r of t&&Array.isArray(t.choices)?t.choices:Array.isArray(e?.choices)?e.choices:[]){if(!r||"object"!=typeof r)continue;let e="message"in r&&r.message&&"object"==typeof r.message?r.message:null;for(let t of e&&Array.isArray(e.content)?e.content:[])if(t&&"object"==typeof t){if("string"==typeof t.image&&t.image.trim())return t.image.trim();if("string"==typeof t.image_url&&t.image_url.trim())return t.image_url.trim()}}return null}(t);return y?{asset:{imageUrl:y,prompt:i.user,negativePrompt:i.negative,providerId:"dashscope",styleLabel:a<=1?"主宇宙回响":`平行回响 ${a}`,echoNote:function(e,t){let r=[`${e} 的基础轮廓与主舰第一次完成同步。`,`${e} 保持稳定，只是外层服装与光谱温度来自另一条分支。`,`${e} 的身份没有改变，这一版更像从侧向宇宙投来的影像。`];return r[Math.max(0,t-1)%r.length]}(e.crew.visualSubject,a),updatedAt:Date.now(),revision:a}}:u.generateCrewImage(e)}},y="nodejs",h="force-dynamic",b=180;async function x(e){let t=null;try{if(t=await e.json(),!t?.crew)return l.NextResponse.json({ok:!1,error:"无效的船员形象请求。"},{status:400});let r=function(){let e=c();if("real"===e.mode&&"dashscope"===e.providerId){if(e.dashscope.apiKey)return m;if(!e.allowMockFallback)throw Error("阿里百炼图像 provider 未配置 DASHSCOPE_API_KEY。")}return u}(),i=await r.generateCrewImage(t);return l.NextResponse.json({ok:!0,providerMode:r.mode,providerId:r.providerId,data:i})}catch(e){return l.NextResponse.json({ok:!1,error:e instanceof Error?e.message:"船员形象回路暂时没有回应。"},{status:500})}}let w=new a.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/ai-image/route",pathname:"/api/ai-image",filename:"route",bundlePath:"app/api/ai-image/route"},resolvedPagePath:"/Users/libaixin/Desktop/ai-game/app/api/ai-image/route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:A,staticGenerationAsyncStorage:v,serverHooks:k}=w,_="/api/ai-image/route";function I(){return(0,s.patchFetch)({serverHooks:k,staticGenerationAsyncStorage:v})}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[276,972,178,774],()=>r(35680));module.exports=i})();